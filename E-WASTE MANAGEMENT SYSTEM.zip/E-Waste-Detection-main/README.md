python version = 3.10.10

cmds:

pip install dill
pip install streamlit
pip install ultralytics
pip install opencv
pip install tensorflow
pip install roboflow

python -m streamlit run deployment.py
